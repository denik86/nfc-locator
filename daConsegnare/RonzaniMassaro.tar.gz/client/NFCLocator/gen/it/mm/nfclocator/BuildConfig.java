/** Automatically generated file. DO NOT MODIFY */
package it.mm.nfclocator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}